from aiogram import Bot
from data.config import BOT_TOKEN

bot = Bot(token=BOT_TOKEN, parse_mode='HTML')

