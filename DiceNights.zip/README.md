# dicenight source code. Create your own telegram casino for free. 

Other people are selling 1:1 scripts of this for up to $10,000

@lolxd8281989282
